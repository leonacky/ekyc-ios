#import <Flutter/Flutter.h>

@interface AssetsAudioPlayerWebPlugin : NSObject<FlutterPlugin>
@end
