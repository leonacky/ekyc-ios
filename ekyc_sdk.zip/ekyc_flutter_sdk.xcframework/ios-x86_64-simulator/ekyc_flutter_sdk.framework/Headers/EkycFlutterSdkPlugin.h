#import <Flutter/Flutter.h>

@interface EkycFlutterSdkPlugin : NSObject<FlutterPlugin>
@end
